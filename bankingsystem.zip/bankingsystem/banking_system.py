from bankingsystem.node import Node
from bankingsystem.customer import Customer


class BankingSystem:

    def __init__(self):
        self.head = None

    def __search(self, account_no):  # pseudo private method to search for account numbers.
        current = self.head
        while current:
            if current.customer.account_no == account_no:
                return current
            current = current.next
        return None

    def __confirmation(self):  # pseudo private method to confirm customer's choice.

        while True:
            for_main_menu = input("In case you entered the number wrongly, do you want go back to main menu(yes/no): ")
            if for_main_menu.isalpha():
                if for_main_menu.lower() == "yes":
                    self.main()
                elif for_main_menu.lower() == "no":
                    break
                else:
                    print("Please enter either 'yes' or 'no'.")
            else:
                print("Enter only 'yes' or 'no'.")

    def __get_unique_account_number(self):  # pseudo private method to get valid and unique account number.

        self.__confirmation()
        print("Fill the following requirements carefully.")
        while True:
            account_no = input(f"Enter 'non-negative' account number in four digits here: ")
            if account_no.isdigit() and len(account_no) == 4:  # To check if the entered account number is valid.
                current = self.head
                while current:
                    if current.customer.account_no == account_no:
                        print("Account number already exists. Please try again.")
                        break  # To get out of the inner loop if the account_number entered is already used account_no.
                    current = current.next
                if current is None:
                    return account_no  # No duplicate found, exit the outer loop to create account with the provided account number.
            else:
                print("Sorry, your account has to be in four digits.")

    def __get_valid_name(self):  # pseudo private method to get valid name.
        while True:
            name = input("Enter your name: ")
            name_without_space = name.replace(" ", "")
            if name_without_space.isalpha():
                return name
            else:
                print("Name should contain only alphabets Please try again.")

    def __get_valid_balance(self):  # pseudo private method to get valid balance.
        while True:
            try:
                balance = int(input("Enter the initial balance: "))
                if balance <= 0:
                    print("Please enter amount greater than zero to create an account.")
                else:
                    return balance
            except ValueError:
                print("Balance should be in numbers.")
                print("Try again.")

    def create_account(self):
        account_no = self.__get_unique_account_number()
        name = self.__get_valid_name()
        balance = self.__get_valid_balance()

        print("Account created successfully.")

        new_customer = Customer(name, account_no, balance)
        new_node = Node(new_customer)
        if self.head is None:
            self.head = new_node
            return
        else:
            current = self.head
            while current.next:
                current = current.next
            current.next = new_node

    def depositing_cash(self):

        self.__confirmation()
        account_no = input("Enter the account number in four digits: ")
        node = self.__search(account_no)
        if node:
            while True:
                try:
                    deposit = int(input('How much do you want to deposit: '))
                    if deposit < 0:
                        print("please enter a non-negative amount.")
                    else:
                        break
                except ValueError:
                    print("Deposit should be a number.")
                    print('Try again.')
            node.customer.balance += deposit
            print('Deposited successfully. Your current balance is ', node.customer.balance, '.')
        else:
            print("Account is not found.")

    def withdrawing_cash(self):

        self.__confirmation()
        account_no = input("Enter the account number in four digits: ")
        node = self.__search(account_no)
        if node:
            while True:
                while True:
                    try:
                        withdraw = int(input('How much do you want to withdraw: '))
                        if withdraw < 0:
                            print("Please enter a non-negative amount.")
                        else:
                            break
                    except ValueError:
                        print("Withdraw amount should be a number.")
                        print('Try again.')
                if node.customer.balance >= withdraw:
                    node.customer.balance -= withdraw
                    print('Successful. Your current balance is ', node.customer.balance, '.')
                    break
                else:
                    print("Your balance is insufficient. your amount is ", node.customer.balance, '.')
        else:
            print('Account is not found')

    def transferring_to_another_account(self):

        self.__confirmation()
        while True:
            sender_account_no = input("Enter your(sender's) account number in four digits: ")
            sender_node = self.__search(sender_account_no)
            if sender_node:
                break
            else:
                print("Sorry, there is no such account, enter the correct account number or create an account with this account number.")

        while True:
            receiver_account_no = input("Enter the receiver's account number in four digits: ")
            receiver_node = self.__search(receiver_account_no)
            if receiver_node:
                break
            else:
                print("Sorry, there is no such account. Try to fill the correct account number again.")

        while True:
            try:
                amount_to_transfer = int(input("How much do you want to transfer: "))
                break
            except ValueError:
                print("Transferring amount should be a number. Try again.")

        print(f"""
                Your(sender's) account number: {sender_node.customer.account_no}
                Your(Sender's) account name: {sender_node.customer.name}
                Receiver's account number: {receiver_node.customer.account_no}
                Receiver's account name: {receiver_node.customer.name}
                Amount to be transferred: {amount_to_transfer}

                To confirm: enter 1
                To cancel: enter 2
                """)

        while True:
            entered_no = int(input("Enter the number of your choice from the above numbers (1 or 2): "))
            if entered_no == 1:
                break
            elif entered_no == 2:
                self.main()
            else:
                print("Please enter either number 1 or number 2.")

        if sender_node.customer.balance < amount_to_transfer:
            print("Your balance is insufficient.")
        else:
            sender_node.customer.balance -= amount_to_transfer
            print(f"Transferred successfully. Your current balance is {sender_node.customer.balance}.")

    def displaying_account_information(self):

        self.__confirmation()
        account_no = input("Enter your account number in four digits: ")
        node = self.__search(account_no)
        if node:
            print(f'''
                      Your account number is {node.customer.account_no}.
                      your account name is {node.customer.name}.
                      your current balance is {node.customer.balance}.
                      ''')
        else:
            print("Invalid or non-existent account number. Please try again.")

    def main(self):
        while True:
            home_page = """
                Welcome! Please use the corresponding numbers to proceed.
                   1) Creating new account
                   2) Cash deposit
                   3) Cash withdrawal
                   4) Transfer to another account
                   5) Display Account information
                   6) Log out
                  """
            print(home_page)
            accept_request = input("Enter your choice(enter the number in front of your choice): ")
            if accept_request.isdigit():
                if int(accept_request) == 1:
                    self.create_account()
                elif int(accept_request) == 2:
                    self.depositing_cash()
                elif int(accept_request) == 3:
                    self.withdrawing_cash()
                elif int(accept_request) == 4:
                    self.transferring_to_another_account()
                elif int(accept_request) == 5:
                    self.displaying_account_information()
                elif int(accept_request) == 6:
                    print("Thank you for banking with us.")
                    break
                else:
                    print("Invalid choice. Please try again.")
            else:
                print("Please enter the provided numbers only.")
