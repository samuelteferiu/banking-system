class Customer:
    def __init__(self, name, account_no, balance):
        self.name = name
        self.account_no = account_no
        self.balance = balance

    def get_name(self):
        return self.name

    def get_account_no(self):
        return self.account_no

    def get_balance(self):
        return self.balance

    def is_account_exist(self):
        if self.account_no:
            return True
        else:
            return False
