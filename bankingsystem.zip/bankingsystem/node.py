class Node:
    def __init__(self, customer):
        self.customer = customer
        self.next = None
